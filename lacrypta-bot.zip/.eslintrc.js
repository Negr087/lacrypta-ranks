module.exports = {
  extends: ["@lacrypta/eslint-config/library.js"],
};
